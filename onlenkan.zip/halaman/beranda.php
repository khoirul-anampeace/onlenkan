<h4>Halaman beranda</h4>
<hr>
<table width="100%" cellspacing="2" cellpadding="5">
	<tr>
		<td width="30%" valign="top">
			<img src="gambar/copy.jpg" width="320px">
		</td>
		<td valign="top" class="sambutan">
			<p><b>Lorem ipsum dolor</b> sit amet, consectetur adipisicing elit. Iure dicta ipsum aliquam distinctio hic vitae fugiat qui ab mollitia dolorem. Eaque dolorem voluptatum omnis vitae eos aut, possimus delectus, odio! dolor sit amet, consectetur adipisicing elit. Explicabo quas corporis totam, sit dolorem. Blanditiis est odio consequatur expedita accusantium molestias dolorem rem magnam consequuntur. Illo aliquam accusamus, similique sapiente consectetur adipisicing elit. Necessitatibus magnam reiciendis facilis mollitia obcaecati porro recusandae totam perspiciatis nam unde a, sed dicta nulla laudantium nemo quisquam cum laboriosam repellat. consectetur adipisicing elit. Explicabo quas corporis totam, sit dolorem. Blanditiis est odio consequatur expedita accusantium molestias dolorem rem magnam consequuntur. Illo aliquam accusamus, similique sapiente consectetur adipisicing elit</p>
		</td>
	</tr>
</table>