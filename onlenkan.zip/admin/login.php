<?php 
session_start();
include '../config/koneksi.php';
if (!empty($_SESSION['username'])) {
	echo "<script>location='.'</script>";
}else{
	if (@$_POST['login']) {
		$username = $_POST['user'];
		$password = $_POST['pass'];
		$sql = mysqli_query($konek,"select * from user where username='$username'and password='$password' ");
		if (mysqli_num_rows($sql)){
			$row = mysqli_fetch_assoc($sql);
			$_SESSION['iduser'] = $row['iduser'];
			$_SESSION['username'] = $row['username'];
			$_SESSION['nama'] = $row['nama'];
			echo "<script>location='.'</script>";
		}else{
			echo "<script>alert('Login Salah');location='login.php'</script>";
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Halaman Login</title>
	<style type="text/css">
		body{
			background: #e5e5e5;
		}
		.bungkus{
			width: 200px;
			height: auto;
			min-height: 150px;
			background: #4848ff;
			box-shadow: 3px 3px 2px #7d7dff;
			margin: 10% auto;
			padding: 20px 10px;
		}
		.button{
			width: 100%;
			padding: 5px;
			background: #1eff00;
			border: none;
			cursor: pointer;
		}
		.isi{
			width: 180px;
			padding: 5px;
			background: #FFF;
			border: none;
		}
		form{
			margin-top: 10px;
		}
	</style>
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>
	<div class="bungkus">
		<div align="center">Form Login</div>
		<form method="post" action="">
			<table width="100%" cellpadding="5" cellspacing="2">
				<tr>
					<td>
						Username<br>
						<input class="isi" type="text" name="user" placeholder="Masukkan username">
					</td>
				</tr>
				<tr>
					<td>
						Password<br>
						<input class="isi" type="password" name="pass" placeholder="Masukkan Password">
					</td>
				</tr>
				<tr>
					<td>
						<input class="button" type="submit" name="login" value="login">
					</td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>