<?php 
	$konek = mysqli_connect("localhost","id12601827_onlenkan","herulpeace1302","id12601827_db_onlenkan")or die("Gagal Konek");